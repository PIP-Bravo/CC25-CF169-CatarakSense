const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
module.exports = {
  entry: "./src/index.js", // Titik masuk utama
  output: {
    filename: "bundle.js",
    path: path.resolve(__dirname, "dist"), // Output ke folder dist
    clean: true, // Bersihkan folder dist setiap build
  },
  mode: "development", // Ganti ke 'production' saat release
  devServer: {
    client: {
      overlay: {
        errors: true,
        warnings: false,
      },
    },
  },
  module: {
    rules: [
      {
        test: /\.css$/i,
        use: [MiniCssExtractPlugin.loader, "css-loader"],
      },
      {
        test: /\.(png|jpe?g|gif|svg)$/i,
        type: "asset/resource",
        generator: {
          filename: 'assets/img/[name][ext]',
        },
      },
      {
        test: /\.js$/,
        exclude: /node_modules/, // Ini harus RegExp, bukan string
        use: {
          loader: "babel-loader",
          options: {
            presets: ["@babel/preset-env"],
          },
        },
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "./src/template.html", // HTML template kamu
      filename: "index.html", // Output HTML di dist/index.html
    }),
     new HtmlWebpackPlugin({
      template: "./src/deteksi.html",
      filename: "deteksi.html",
    }),
     new HtmlWebpackPlugin({
      template: "./src/kontak.html",
      filename: "kontak.html",
    }),
    new MiniCssExtractPlugin({
      filename: 'styles.css',
    }),
  ],
};
